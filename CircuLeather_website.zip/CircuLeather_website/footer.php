<?php
declare(strict_types=1);
?>

        </div>
    </main>
</div>

<script src="app.js"></script>
</body>
</html>
