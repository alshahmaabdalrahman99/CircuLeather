<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare(
    'SELECT
        lp.*,
        l.naam AS locatie
     FROM leerpartijen lp
     JOIN locaties l
        ON l.id = lp.locatie_id
     WHERE lp.id = :id'
);

$stmt->execute([
    ':id' => $id
]);

$party = $stmt->fetch();

if (!$party) {
    http_response_code(404);
    exit('Leerpartij niet gevonden.');
}

$pageTitle =
    'Leerpartij ' .
    $party['label'];

include __DIR__ . '/header.php';
?>

<div class="page-head">

    <div>
        <a
            class="back-link"
            href="leerpartijen.php"
        >
            ← Terug naar overzicht
        </a>

        <h1>
            Leerpartij <?= e($party['label']) ?>
        </h1>

        <p>
            Detailgegevens van deze leerpartij.
        </p>
    </div>

    <div class="head-actions">

        <a
            class="btn btn-secondary"
            href="partij_bewerken.php?id=<?= $party['id'] ?>"
        >
            ✎ Aanpassen
        </a>

        <?php if (is_admin()): ?>

            <form
                method="post"
                action="partij_verwijderen.php"
                class="inline-form"
                data-confirm="Weet je zeker dat je deze leerpartij wilt verwijderen?"
            >

                <?= csrf_field() ?>

                <input
                    type="hidden"
                    name="id"
                    value="<?= $party['id'] ?>"
                >

                <button
                    class="btn btn-danger"
                    type="submit"
                >
                    🗑 Verwijderen
                </button>

            </form>

        <?php endif; ?>

    </div>

</div>

<div class="detail-grid">

    <section class="card detail-card">

        <div class="detail-row">
            <span>Label</span>
            <strong><?= e($party['label']) ?></strong>
        </div>

        <div class="detail-row">
            <span>Herkomst</span>
            <strong><?= e($party['herkomst']) ?></strong>
        </div>

        <div class="detail-row">
            <span>Locatie</span>
            <strong><?= e($party['locatie']) ?></strong>
        </div>

        <div class="detail-row">
            <span>Gewicht</span>
            <strong>
                <?= number_format(
                    (float) $party['gewicht_kg'],
                    2,
                    ',',
                    '.'
                ) ?> kg
            </strong>
        </div>

        <div class="detail-row">
            <span>Datum toegevoegd</span>
            <strong>
                <?= e(
                    date(
                        'd-m-Y',
                        strtotime(
                            $party['datum_toegevoegd']
                        )
                    )
                ) ?>
            </strong>
        </div>

        <div class="detail-row">
            <span>Status</span>
            <strong>
                <span
                    class="status <?= status_class(
                        $party['status']
                    ) ?>"
                >
                    <?= e($party['status']) ?>
                </span>
            </strong>
        </div>

        <div class="detail-row">
            <span>Kleur</span>
            <strong>
                <?= e($party['kleur'] ?: '-') ?>
            </strong>
        </div>

        <div class="detail-row">
            <span>Formaat</span>
            <strong>
                <?= e($party['formaat'] ?: '-') ?>
            </strong>
        </div>

        <div class="detail-row">
            <span>Dikte</span>
            <strong>
                <?= $party['dikte_mm'] !== null
                    ? e(
                        number_format(
                            (float) $party['dikte_mm'],
                            2,
                            ',',
                            '.'
                        ) . ' mm'
                    )
                    : '-' ?>
            </strong>
        </div>

        <div class="detail-row">
            <span>Opmerking</span>
            <strong>
                <?= nl2br(
                    e(
                        $party['opmerking'] ?: '-'
                    )
                ) ?>
            </strong>
        </div>

    </section>

    <section class="card visual-card">

        <?php if (!empty($party['foto'])): ?>

            <img
                class="party-photo"
                src="<?= e(
                    UPLOAD_URL .
                    '/' .
                    basename($party['foto'])
                ) ?>"
                alt="Foto van <?= e($party['label']) ?>"
            >

        <?php else: ?>

            <div class="mock-leather">
                CircuLeather
            </div>

        <?php endif; ?>

        <p>Foto van de leerpartij</p>

        <?php if (empty($party['foto'])): ?>
            <small>
                Je kunt een foto toevoegen via Aanpassen.
            </small>
        <?php endif; ?>

    </section>

</div>

<?php include __DIR__ . '/footer.php'; ?>
