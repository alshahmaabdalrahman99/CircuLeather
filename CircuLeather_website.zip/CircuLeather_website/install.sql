CREATE DATABASE IF NOT EXISTS circuleather
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE circuleather;

-- Tabel met gebruikers van het systeem.
CREATE TABLE IF NOT EXISTS gebruikers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    naam VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    wachtwoord_hash VARCHAR(255) NOT NULL,
    rol ENUM('admin', 'user') NOT NULL DEFAULT 'user',
    actief TINYINT(1) NOT NULL DEFAULT 1,
    aangemaakt_op TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gewijzigd_op TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabel met magazijnen en andere opslaglocaties.
CREATE TABLE IF NOT EXISTS locaties (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    naam VARCHAR(100) NOT NULL UNIQUE,
    omschrijving VARCHAR(255) NULL,
    actief TINYINT(1) NOT NULL DEFAULT 1,
    aangemaakt_op TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Hoofdtabel van het systeem: alle leerpartijen.
CREATE TABLE IF NOT EXISTS leerpartijen (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    label VARCHAR(20) NOT NULL UNIQUE,
    herkomst VARCHAR(255) NOT NULL,
    locatie_id INT UNSIGNED NOT NULL,
    gewicht_kg DECIMAL(10, 2) NOT NULL,
    datum_toegevoegd DATE NOT NULL,
    status ENUM(
        'Op voorraad',
        'Gereserveerd',
        'Verwerkt'
    ) NOT NULL DEFAULT 'Op voorraad',
    kleur VARCHAR(100) NULL,
    formaat VARCHAR(100) NULL,
    dikte_mm DECIMAL(6, 2) NULL,
    opmerking TEXT NULL,
    foto VARCHAR(255) NULL,
    aangemaakt_op TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gewijzigd_op TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_label (label),
    INDEX idx_status (status),
    INDEX idx_locatie (locatie_id),

    CONSTRAINT fk_leerpartij_locatie
        FOREIGN KEY (locatie_id)
        REFERENCES locaties(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Demo-beheerder voor de lokale schoolinstallatie.
-- Login: admin@circuleather.nl
-- Wachtwoord: Admin123!
INSERT INTO gebruikers (
    naam,
    email,
    wachtwoord_hash,
    rol,
    actief
)
VALUES (
    'CircuLeather Admin',
    'admin@circuleather.nl',
    '$2y$12$.LdgPr1TeFPMV6py/WawRu58LstRmH2PRRuR90H9cFc2529uYfdIm',
    'admin',
    1
)
ON DUPLICATE KEY UPDATE
    naam = VALUES(naam),
    wachtwoord_hash = VALUES(wachtwoord_hash),
    rol = VALUES(rol),
    actief = VALUES(actief);

-- Vier testlocaties.
INSERT INTO locaties (
    naam,
    omschrijving,
    actief
)
VALUES
    ('Magazijn A', 'Hoofdmagazijn', 1),
    ('Magazijn B', 'Tijdelijke opslag', 1),
    ('Magazijn C', 'Verwerking', 1),
    ('Magazijn D', 'Externe opslag', 1)
ON DUPLICATE KEY UPDATE
    omschrijving = VALUES(omschrijving),
    actief = VALUES(actief);

-- Tien testpartijen.
INSERT IGNORE INTO leerpartijen (
    label,
    herkomst,
    locatie_id,
    gewicht_kg,
    datum_toegevoegd,
    status,
    kleur,
    formaat,
    dikte_mm,
    opmerking
)
VALUES
    (
        'CL-00001',
        'Amsterdam',
        1,
        125.00,
        '2026-09-21',
        'Op voorraad',
        'Bruin',
        '120 x 80 cm',
        2.00,
        'Eerste testpartij'
    ),
    (
        'CL-00002',
        'Rotterdam',
        2,
        80.00,
        '2026-09-20',
        'Op voorraad',
        'Zwart',
        '100 x 70 cm',
        1.80,
        NULL
    ),
    (
        'CL-00003',
        'Utrecht',
        1,
        210.00,
        '2026-09-18',
        'Op voorraad',
        'Bruin',
        '150 x 100 cm',
        2.20,
        NULL
    ),
    (
        'CL-00004',
        'Den Haag',
        3,
        95.00,
        '2026-09-17',
        'Op voorraad',
        'Donkerbruin',
        '110 x 75 cm',
        2.50,
        'Goede kwaliteit'
    ),
    (
        'CL-00005',
        'Groningen',
        2,
        120.00,
        '2026-09-16',
        'Op voorraad',
        'Zwart',
        '130 x 90 cm',
        1.60,
        NULL
    ),
    (
        'CL-00006',
        'Eindhoven',
        1,
        175.00,
        '2026-09-15',
        'Op voorraad',
        'Cognac',
        '140 x 90 cm',
        2.10,
        'Geschikt voor meubels'
    ),
    (
        'CL-00007',
        'Arnhem',
        3,
        65.00,
        '2026-09-14',
        'Gereserveerd',
        'Beige',
        '90 x 60 cm',
        1.40,
        'Gereserveerd voor klant'
    ),
    (
        'CL-00008',
        'Tilburg',
        4,
        240.00,
        '2026-09-13',
        'Op voorraad',
        'Donkerbruin',
        '160 x 110 cm',
        2.80,
        'Grote leerpartij'
    ),
    (
        'CL-00009',
        'Breda',
        2,
        55.00,
        '2026-09-12',
        'Op voorraad',
        'Roodbruin',
        '85 x 60 cm',
        1.90,
        NULL
    ),
    (
        'CL-00010',
        'Almere',
        3,
        145.00,
        '2026-09-11',
        'Verwerkt',
        'Bruin',
        '125 x 85 cm',
        2.30,
        'Gedeeltelijk verwerkt'
    );
