<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

$id = (int) ($_GET['id'] ?? 0);

$get = $pdo->prepare(
    'SELECT *
     FROM leerpartijen
     WHERE id = :id'
);

$get->execute([
    ':id' => $id
]);

$party = $get->fetch();

if (!$party) {
    http_response_code(404);
    exit('Leerpartij niet gevonden.');
}

$locations = $pdo
    ->query(
        'SELECT id, naam
         FROM locaties
         WHERE actief = 1
         ORDER BY naam'
    )
    ->fetchAll();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $herkomst = trim(
        $_POST['herkomst'] ?? ''
    );

    $locatieId = (int) (
        $_POST['locatie_id'] ?? 0
    );

    $gewicht = str_replace(
        ',',
        '.',
        trim($_POST['gewicht_kg'] ?? '')
    );

    $datum =
        $_POST['datum_toegevoegd'] ??
        date('Y-m-d');

    $status = trim(
        $_POST['status'] ?? 'Op voorraad'
    );

    $kleur = trim(
        $_POST['kleur'] ?? ''
    );

    $formaat = trim(
        $_POST['formaat'] ?? ''
    );

    $dikte = str_replace(
        ',',
        '.',
        trim($_POST['dikte_mm'] ?? '')
    );

    $opmerking = trim(
        $_POST['opmerking'] ?? ''
    );

    if ($herkomst === '') {
        $errors[] = 'Herkomst is verplicht.';
    }

    if ($locatieId <= 0) {
        $errors[] = 'Kies een locatie.';
    }

    if (
        $gewicht === '' ||
        !is_numeric($gewicht) ||
        (float) $gewicht < 0
    ) {
        $errors[] = 'Vul een geldig gewicht in.';
    }

    if (
        $dikte !== '' &&
        (
            !is_numeric($dikte) ||
            (float) $dikte < 0
        )
    ) {
        $errors[] =
            'Dikte moet een positief getal zijn.';
    }

    $newPhoto = $party['foto'];
    $uploaded = null;

    if (
        !$errors &&
        !empty($_FILES['foto']['name'] ?? '')
    ) {
        try {
            $uploaded = save_uploaded_image(
                $_FILES['foto']
            );

            $newPhoto = $uploaded;
        } catch (Throwable $e) {
            $errors[] = $e->getMessage();
        }
    }

    if (!$errors) {
        $stmt = $pdo->prepare(
            'UPDATE leerpartijen
             SET
                herkomst = :herkomst,
                locatie_id = :locatie,
                gewicht_kg = :gewicht,
                datum_toegevoegd = :datum,
                status = :status,
                kleur = :kleur,
                formaat = :formaat,
                dikte_mm = :dikte,
                opmerking = :opmerking,
                foto = :foto
             WHERE id = :id'
        );

        $stmt->execute([
            ':herkomst' => $herkomst,
            ':locatie' => $locatieId,
            ':gewicht' => (float) $gewicht,
            ':datum' => $datum,
            ':status' => $status,
            ':kleur' => $kleur ?: null,
            ':formaat' => $formaat ?: null,
            ':dikte' => $dikte !== ''
                ? (float) $dikte
                : null,
            ':opmerking' => $opmerking ?: null,
            ':foto' => $newPhoto,
            ':id' => $id
        ]);

        if ($uploaded && $party['foto']) {
            delete_uploaded_image(
                $party['foto']
            );
        }

        flash(
            'success',
            'Wijzigingen zijn opgeslagen.'
        );

        redirect(
            'partij_bekijken.php?id=' . $id
        );
    }

    if ($uploaded) {
        delete_uploaded_image($uploaded);
    }

    $party = array_merge(
        $party,
        [
            'herkomst' => $herkomst,
            'locatie_id' => $locatieId,
            'gewicht_kg' => $gewicht,
            'datum_toegevoegd' => $datum,
            'status' => $status,
            'kleur' => $kleur,
            'formaat' => $formaat,
            'dikte_mm' => $dikte,
            'opmerking' => $opmerking
        ]
    );
}

$pageTitle = 'Leerpartij aanpassen';

include __DIR__ . '/header.php';
?>

<div class="page-head">

    <div>
        <a
            class="back-link"
            href="partij_bekijken.php?id=<?= $party['id'] ?>"
        >
            ← Terug naar leerpartij
        </a>

        <h1>Leerpartij aanpassen</h1>

        <p>
            <?= e($party['label']) ?>
        </p>
    </div>

</div>

<?php if ($errors): ?>

    <div class="alert alert-error">

        <?php foreach ($errors as $error): ?>
            <div><?= e($error) ?></div>
        <?php endforeach; ?>

    </div>

<?php endif; ?>

<section class="card form-card">

<form
    method="post"
    enctype="multipart/form-data"
>

    <?= csrf_field() ?>

    <div class="form-grid">

        <div class="form-group full">
            <label>Label</label>

            <input
                value="<?= e($party['label']) ?>"
                readonly
            >

            <small>
                Het unieke label kan niet worden aangepast.
            </small>
        </div>

        <div class="form-group full">
            <label for="herkomst">
                Herkomst <span>*</span>
            </label>

            <input
                id="herkomst"
                name="herkomst"
                value="<?= e($party['herkomst']) ?>"
                required
            >
        </div>

        <div class="form-group">
            <label for="locatie_id">
                Locatie <span>*</span>
            </label>

            <select
                id="locatie_id"
                name="locatie_id"
                required
            >
                <?php foreach ($locations as $location): ?>

                    <option
                        value="<?= $location['id'] ?>"
                        <?= (int) $party['locatie_id'] ===
                            (int) $location['id']
                            ? 'selected'
                            : '' ?>
                    >
                        <?= e($location['naam']) ?>
                    </option>

                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="gewicht_kg">
                Gewicht (kg) <span>*</span>
            </label>

            <input
                id="gewicht_kg"
                name="gewicht_kg"
                type="number"
                step="0.01"
                min="0"
                value="<?= e($party['gewicht_kg']) ?>"
                required
            >
        </div>

        <div class="form-group">
            <label for="kleur">Kleur</label>

            <input
                id="kleur"
                name="kleur"
                value="<?= e($party['kleur']) ?>"
            >
        </div>

        <div class="form-group">
            <label for="formaat">Formaat</label>

            <input
                id="formaat"
                name="formaat"
                value="<?= e($party['formaat']) ?>"
            >
        </div>

        <div class="form-group">
            <label for="dikte_mm">Dikte (mm)</label>

            <input
                id="dikte_mm"
                name="dikte_mm"
                type="number"
                step="0.01"
                min="0"
                value="<?= e($party['dikte_mm']) ?>"
            >
        </div>

        <div class="form-group">
            <label for="datum_toegevoegd">
                Datum toegevoegd
            </label>

            <input
                id="datum_toegevoegd"
                name="datum_toegevoegd"
                type="date"
                value="<?= e($party['datum_toegevoegd']) ?>"
            >
        </div>

        <div class="form-group">
            <label for="status">Status</label>

            <select
                id="status"
                name="status"
            >

                <?php foreach (
                    [
                        'Op voorraad',
                        'Gereserveerd',
                        'Verwerkt'
                    ] as $option
                ): ?>

                    <option
                        value="<?= e($option) ?>"
                        <?= $party['status'] === $option
                            ? 'selected'
                            : '' ?>
                    >
                        <?= e($option) ?>
                    </option>

                <?php endforeach; ?>

            </select>
        </div>

        <div class="form-group">
            <label for="foto">Nieuwe foto</label>

            <input
                id="foto"
                name="foto"
                type="file"
                accept="image/jpeg,image/png,image/webp"
            >

            <small>
                Laat leeg om de huidige foto te behouden.
            </small>
        </div>

        <div class="form-group full">
            <label for="opmerking">Opmerking</label>

            <textarea
                id="opmerking"
                name="opmerking"
                rows="4"
            ><?= e($party['opmerking']) ?></textarea>
        </div>

    </div>

    <div class="form-actions">
        <a
            class="btn btn-secondary"
            href="partij_bekijken.php?id=<?= $party['id'] ?>"
        >
            Annuleren
        </a>

        <button
            class="btn btn-primary"
            type="submit"
        >
            Wijzigingen opslaan
        </button>
    </div>

</form>

</section>

<?php include __DIR__ . '/footer.php'; ?>
