USE circuleather;

SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE leerpartijen;
TRUNCATE TABLE locaties;
TRUNCATE TABLE gebruikers;

SET FOREIGN_KEY_CHECKS = 1;

SOURCE install.sql;
