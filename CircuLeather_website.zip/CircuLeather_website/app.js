document.addEventListener(
    'submit',
    function (event) {
        const form = event.target;
        const message = form.dataset.confirm;

        if (!message) {
            return;
        }

        if (!window.confirm(message)) {
            event.preventDefault();
        }
    }
);
