<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

require_admin();

$pageTitle = 'Gebruikers';

$stmt = $pdo->query(
    'SELECT
        id,
        naam,
        email,
        rol,
        actief,
        aangemaakt_op
     FROM gebruikers
     ORDER BY naam'
);

$users = $stmt->fetchAll();

include __DIR__ . '/header.php';
?>

<div class="page-head">

    <div>
        <h1>Gebruikers</h1>

        <p>
            Beheer wie toegang heeft tot CircuLeather.
        </p>
    </div>

    <a
        class="btn btn-primary"
        href="gebruiker_toevoegen.php"
    >
        ＋ Nieuwe gebruiker
    </a>

</div>

<section class="card">

<div class="table-wrap">

<table>

<thead>
    <tr>
        <th>Naam</th>
        <th>E-mail</th>
        <th>Rol</th>
        <th>Status</th>
        <th>Acties</th>
    </tr>
</thead>

<tbody>

<?php foreach ($users as $user): ?>

    <tr>

        <td>
            <strong>
                <?= e($user['naam']) ?>
            </strong>
        </td>

        <td>
            <?= e($user['email']) ?>
        </td>

        <td>
            <?= e($user['rol']) ?>
        </td>

        <td>

            <span
                class="status <?= (int) $user['actief'] === 1
                    ? 'status-green'
                    : 'status-gray' ?>"
            >
                <?= (int) $user['actief'] === 1
                    ? 'Actief'
                    : 'Inactief' ?>
            </span>

        </td>

        <td>

            <a
                class="icon-btn"
                href="gebruiker_bewerken.php?id=<?= $user['id'] ?>"
                title="Bewerken"
            >
                ✎
            </a>

        </td>

    </tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

</section>

<?php include __DIR__ . '/footer.php'; ?>
