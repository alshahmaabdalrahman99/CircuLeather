<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

/* Gebruiker controleren en een sessie starten. */
function login_user(
    string $email,
    string $password
): bool {
    global $pdo;

    $stmt = $pdo->prepare(
        'SELECT
            id,
            naam,
            email,
            wachtwoord_hash,
            rol,
            actief
         FROM gebruikers
         WHERE email = :email
         LIMIT 1'
    );

    $stmt->execute([
        ':email' => $email
    ]);

    $user = $stmt->fetch();

    if (!$user) {
        return false;
    }

    if ((int) $user['actief'] !== 1) {
        return false;
    }

    if (!password_verify(
        $password,
        $user['wachtwoord_hash']
    )) {
        return false;
    }

    session_regenerate_id(true);#tijdelijk geheugen.

    $_SESSION['user'] = [
        'id' => (int) $user['id'],
        'naam' => $user['naam'],
        'email' => $user['email'],
        'rol' => $user['rol']
    ];

    return true;
}

function logout_user(): void
{
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            (bool) $params['secure'],
            (bool) $params['httponly']
        );
    }

    session_destroy();
}
