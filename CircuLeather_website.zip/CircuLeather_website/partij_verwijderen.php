<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('leerpartijen.php');
}

verify_csrf();

$id = (int) ($_POST['id'] ?? 0);

$stmt = $pdo->prepare(
    'SELECT label, foto
     FROM leerpartijen
     WHERE id = :id'
);

$stmt->execute([
    ':id' => $id
]);

$party = $stmt->fetch();

if (!$party) {
    flash('error', 'Leerpartij bestaat niet meer.');
    redirect('leerpartijen.php');
}

$delete = $pdo->prepare(
    'DELETE FROM leerpartijen
     WHERE id = :id'
);

$delete->execute([
    ':id' => $id
]);

delete_uploaded_image($party['foto']);

flash(
    'success',
    "Leerpartij {$party['label']} is verwijderd."
);

redirect('leerpartijen.php');
