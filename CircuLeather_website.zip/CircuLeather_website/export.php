<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

require_login();

header(
    'Content-Type: text/csv; charset=UTF-8'
);

header(
    'Content-Disposition: attachment; ' .
    'filename="circuleather_leerpartijen.csv"'
);

$output = fopen(
    'php://output',
    'w'
);

/* UTF-8 BOM zodat Excel Nederlandse tekens goed leest. */
fwrite(
    $output,
    "\xEF\xBB\xBF"
);

fputcsv(
    $output,
    [
        'Label',
        'Herkomst',
        'Locatie',
        'Gewicht kg',
        'Datum toegevoegd',
        'Status',
        'Kleur',
        'Formaat',
        'Dikte mm',
        'Opmerking'
    ],
    ';'
);

$stmt = $pdo->query(
    'SELECT
        lp.label,
        lp.herkomst,
        l.naam AS locatie,
        lp.gewicht_kg,
        lp.datum_toegevoegd,
        lp.status,
        lp.kleur,
        lp.formaat,
        lp.dikte_mm,
        lp.opmerking
     FROM leerpartijen lp
     JOIN locaties l
        ON l.id = lp.locatie_id
     ORDER BY lp.id DESC'
);

while ($row = $stmt->fetch()) {
    fputcsv(
        $output,
        $row,
        ';'
    );
}

fclose($output);
exit;
