<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

$pageTitle = 'Locaties';

$stmt = $pdo->query(
    "SELECT
        l.id,
        l.naam,
        l.omschrijving,
        COUNT(lp.id) AS aantal,
        COALESCE(
            SUM(
                CASE
                    WHEN lp.status = 'Op voorraad'
                    THEN lp.gewicht_kg
                    ELSE 0
                END
            ),
            0
        ) AS voorraad
     FROM locaties l
     LEFT JOIN leerpartijen lp
        ON lp.locatie_id = l.id
     WHERE l.actief = 1
     GROUP BY
        l.id,
        l.naam,
        l.omschrijving
     ORDER BY l.naam"
);

$locations = $stmt->fetchAll();

include __DIR__ . '/header.php';
?>

<div class="page-head">

    <div>
        <h1>Locaties</h1>

        <p>
            Beheer magazijnen en opslaglocaties.
        </p>
    </div>

    <?php if (is_admin()): ?>

        <a
            class="btn btn-primary"
            href="locatie_toevoegen.php"
        >
            ＋ Nieuwe locatie
        </a>

    <?php endif; ?>

</div>

<section class="card">

<div class="table-wrap">

<table>

<thead>
    <tr>
        <th>Naam</th>
        <th>Omschrijving</th>
        <th>Aantal partijen</th>
        <th>Voorraad</th>
        <th>Acties</th>
    </tr>
</thead>

<tbody>

<?php foreach ($locations as $location): ?>

    <tr>

        <td>
            <strong>
                <?= e($location['naam']) ?>
            </strong>
        </td>

        <td>
            <?= e(
                $location['omschrijving'] ?: '-'
            ) ?>
        </td>

        <td>
            <?= (int) $location['aantal'] ?>
        </td>

        <td>
            <?= number_format(
                (float) $location['voorraad'],
                2,
                ',',
                '.'
            ) ?> kg
        </td>

        <td>

            <?php if (is_admin()): ?>

                <div class="actions">

                    <a
                        class="icon-btn"
                        href="locatie_bewerken.php?id=<?= $location['id'] ?>"
                    >
                        ✎
                    </a>

                    <form
                        method="post"
                        action="locatie_verwijderen.php"
                        class="inline-form"
                        data-confirm="Weet je zeker dat je deze locatie wilt deactiveren?"
                    >

                        <?= csrf_field() ?>

                        <input
                            type="hidden"
                            name="id"
                            value="<?= $location['id'] ?>"
                        >

                        <button
                            class="icon-btn danger"
                            type="submit"
                            title="Deactiveren"
                        >
                            🗑
                        </button>

                    </form>

                </div>

            <?php else: ?>
                -
            <?php endif; ?>

        </td>

    </tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

</section>

<?php include __DIR__ . '/footer.php'; ?>
