<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

$pageTitle = 'Nieuwe leerpartij';
$errors = [];

$locations = $pdo
    ->query(
        'SELECT id, naam
         FROM locaties
         WHERE actief = 1
         ORDER BY naam'
    )
    ->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $herkomst = trim(
        $_POST['herkomst'] ?? ''
    );

    $locatieId = (int) (
        $_POST['locatie_id'] ?? 0
    );

    $gewicht = str_replace(
        ',',
        '.',
        trim($_POST['gewicht_kg'] ?? '')
    );

    $datum =
        $_POST['datum_toegevoegd'] ??
        date('Y-m-d');

    $status = trim(
        $_POST['status'] ?? 'Op voorraad'
    );

    $kleur = trim(
        $_POST['kleur'] ?? ''
    );

    $formaat = trim(
        $_POST['formaat'] ?? ''
    );

    $dikte = str_replace(
        ',',
        '.',
        trim($_POST['dikte_mm'] ?? '')
    );

    $opmerking = trim(
        $_POST['opmerking'] ?? ''
    );

    /* Verplichte velden controleren. */
    if ($herkomst === '') {
        $errors[] =
            'Herkomst is verplicht.';
    }

    if ($locatieId <= 0) {
        $errors[] =
            'Kies een locatie.';
    }

    if (
        $gewicht === '' ||
        !is_numeric($gewicht) ||
        (float) $gewicht < 0
    ) {
        $errors[] =
            'Vul een geldig gewicht in.';
    }

    if (
        $dikte !== '' &&
        (
            !is_numeric($dikte) ||
            (float) $dikte < 0
        )
    ) {
        $errors[] =
            'Dikte moet een positief getal zijn.';
    }

    $foto = null;

    try {
        $foto = save_uploaded_image(
            $_FILES['foto'] ?? []
        );
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }
    #Een transactie groepeert meerdere databasebewerkingen. PHP voert ze als één geheel uit.
    if (!$errors) {
        try {
            $pdo->beginTransaction();

            /* Tijdelijk label voorkomt problemen vóór het ID bekend is. */
            $temporaryLabel =
                'TMP-' .
                bin2hex(random_bytes(12));

            $stmt = $pdo->prepare(
                'INSERT INTO leerpartijen (
                    label,
                    herkomst,
                    locatie_id,
                    gewicht_kg,
                    datum_toegevoegd,
                    status,
                    kleur,
                    formaat,
                    dikte_mm,
                    opmerking,
                    foto
                ) VALUES (
                    :label,
                    :herkomst,
                    :locatie,
                    :gewicht,
                    :datum,
                    :status,
                    :kleur,
                    :formaat,
                    :dikte,
                    :opmerking,
                    :foto
                )'
            );

            $stmt->execute([
                ':label' => $temporaryLabel,
                ':herkomst' => $herkomst,
                ':locatie' => $locatieId,
                ':gewicht' => (float) $gewicht,
                ':datum' => $datum,
                ':status' => $status,
                ':kleur' => $kleur ?: null,
                ':formaat' => $formaat ?: null,
                ':dikte' => $dikte !== ''
                    ? (float) $dikte
                    : null,
                ':opmerking' => $opmerking ?: null,
                ':foto' => $foto
            ]);

            $id = (int) $pdo->lastInsertId();

            /* Uniek zichtbaar label maken. */
            $label =
                'CL-' .
                str_pad(
                    (string) $id,
                    5,
                    '0',
                    STR_PAD_LEFT
                );

            $update = $pdo->prepare(
                'UPDATE leerpartijen
                 SET label = :label
                 WHERE id = :id'
            );

            $update->execute([
                ':label' => $label,
                ':id' => $id
            ]);

            $pdo->commit();

            flash(
                'success',
                "Leerpartij $label is toegevoegd."
            );

            redirect(
                'partij_bekijken.php?id=' . $id
            );
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            delete_uploaded_image($foto);

            $errors[] =
                'Opslaan is mislukt: ' .
                $e->getMessage();
        }
    } elseif ($foto) {
        delete_uploaded_image($foto);
    }
}

include __DIR__ . '/header.php';
?>

<div class="page-head">

    <div>
        <a
            class="back-link"
            href="leerpartijen.php"
        >
            ← Terug naar overzicht
        </a>

        <h1>Nieuwe leerpartij</h1>

        <p>
            Registreer een nieuwe partij in de database.
        </p>
    </div>

</div>

<?php if ($errors): ?>

    <div class="alert alert-error">

        <?php foreach ($errors as $error): ?>
            <div><?= e($error) ?></div>
        <?php endforeach; ?>

    </div>

<?php endif; ?>

<section class="card form-card">

<form
    method="post"
    enctype="multipart/form-data"
>

    <?= csrf_field() ?>

    <div class="form-grid">

        <div class="form-group">
            <label>Label</label>

            <input
                value="Automatisch na opslaan"
                readonly
            >

            <small>
                Bijvoorbeeld CL-00011.
            </small>
        </div>

        <div class="form-group">
            <label for="datum_toegevoegd">
                Datum toegevoegd
            </label>

            <input
                id="datum_toegevoegd"
                name="datum_toegevoegd"
                type="date"
                value="<?= e(
                    $_POST['datum_toegevoegd'] ??
                    date('Y-m-d')
                ) ?>"
            >
        </div>

        <div class="form-group full">
            <label for="herkomst">
                Herkomst <span>*</span>
            </label>

            <input
                id="herkomst"
                name="herkomst"
                value="<?= e(
                    $_POST['herkomst'] ?? ''
                ) ?>"
                placeholder="Bijv. Leerlooierij Amsterdam"
                required
            >
        </div>

        <div class="form-group">
            <label for="locatie_id">
                Locatie <span>*</span>
            </label>

            <select
                id="locatie_id"
                name="locatie_id"
                required
            >
                <option value="">
                    Selecteer een locatie
                </option>

                <?php foreach ($locations as $location): ?>
                    <option
                        value="<?= $location['id'] ?>"
                        <?= (string) $location['id'] ===
                            ($_POST['locatie_id'] ?? '')
                            ? 'selected'
                            : '' ?>
                    >
                        <?= e($location['naam']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="gewicht_kg">
                Gewicht (kg) <span>*</span>
            </label>

            <input
                id="gewicht_kg"
                name="gewicht_kg"
                type="number"
                step="0.01"
                min="0"
                value="<?= e(
                    $_POST['gewicht_kg'] ?? ''
                ) ?>"
                placeholder="Bijv. 125"
                required
            >
        </div>

        <div class="form-group">
            <label for="kleur">
                Kleur
            </label>

            <input
                id="kleur"
                name="kleur"
                value="<?= e(
                    $_POST['kleur'] ?? ''
                ) ?>"
                placeholder="Bijv. Bruin"
            >
        </div>

        <div class="form-group">
            <label for="formaat">
                Formaat
            </label>

            <input
                id="formaat"
                name="formaat"
                value="<?= e(
                    $_POST['formaat'] ?? ''
                ) ?>"
                placeholder="Bijv. 120 x 80 cm"
            >
        </div>

        <div class="form-group">
            <label for="dikte_mm">
                Dikte (mm)
            </label>

            <input
                id="dikte_mm"
                name="dikte_mm"
                type="number"
                step="0.01"
                min="0"
                value="<?= e(
                    $_POST['dikte_mm'] ?? ''
                ) ?>"
                placeholder="Bijv. 2"
            >
        </div>

        <div class="form-group">
            <label for="status">
                Status
            </label>

            <select
                id="status"
                name="status"
            >

                <?php foreach (
                    [
                        'Op voorraad',
                        'Gereserveerd',
                        'Verwerkt'
                    ] as $option
                ): ?>

                    <option
                        value="<?= e($option) ?>"
                        <?= (
                            $_POST['status'] ??
                            'Op voorraad'
                        ) === $option
                            ? 'selected'
                            : '' ?>
                    >
                        <?= e($option) ?>
                    </option>

                <?php endforeach; ?>

            </select>
        </div>

        <div class="form-group full">
            <label for="foto">Foto</label>

            <input
                id="foto"
                name="foto"
                type="file"
                accept="image/jpeg,image/png,image/webp"
            >

            <small>
                JPG, PNG of WEBP, maximaal 5 MB.
            </small>
        </div>

        <div class="form-group full">
            <label for="opmerking">
                Opmerking
            </label>

            <textarea
                id="opmerking"
                name="opmerking"
                rows="4"
                placeholder="Extra informatie..."
            ><?= e(
                $_POST['opmerking'] ?? ''
            ) ?></textarea>
        </div>

    </div>

    <div class="form-actions">
        <a
            class="btn btn-secondary"
            href="leerpartijen.php"
        >
            Annuleren
        </a>

        <button
            class="btn btn-primary"
            type="submit"
        >
            Leerpartij opslaan
        </button>
    </div>

</form>

</section>

<?php include __DIR__ . '/footer.php'; ?>
