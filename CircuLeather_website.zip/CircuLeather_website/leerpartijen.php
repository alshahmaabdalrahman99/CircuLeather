<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

$pageTitle = 'Leerpartijen';

$search = trim($_GET['zoek'] ?? '');
$status = trim($_GET['status'] ?? '');
$locationId = (int) ($_GET['locatie_id'] ?? 0);

$page = max(
    1,
    (int) ($_GET['pagina'] ?? 1)
);

$perPage = 10;
$where = ['1=1'];
$params = [];



/* Zoek op label, herkomst of locatie. */
if ($search !== '') {
    $where[] =
        '(lp.label LIKE :zoek1
        OR lp.herkomst LIKE :zoek2
        OR l.naam LIKE :zoek3)';

    $zoekterm = '%' . $search . '%';

    $params[':zoek1'] = $zoekterm;
    $params[':zoek2'] = $zoekterm;
    $params[':zoek3'] = $zoekterm;
}

/* Filter op status. */
if ($status !== '') {
    $where[] = 'lp.status = :status';
    $params[':status'] = $status;
}

/* Filter op locatie. */
if ($locationId > 0) {
    $where[] = 'lp.locatie_id = :locatie_id';
    $params[':locatie_id'] = $locationId;
}

$whereSql = implode(' AND ', $where);

/* Eerst het aantal resultaten bepalen. */
$countStmt = $pdo->prepare(
    "SELECT COUNT(*) AS totaal
     FROM leerpartijen lp
     JOIN locaties l
        ON l.id = lp.locatie_id
     WHERE $whereSql"
);

$countStmt->execute($params);
$total = (int) $countStmt->fetch()['totaal'];

$totalPages = max(
    1,
    (int) ceil($total / $perPage)
);

$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

/* Gegevens voor de tabel ophalen. */
$stmt = $pdo->prepare(
    "SELECT
        lp.*,
        l.naam AS locatie
     FROM leerpartijen lp
     JOIN locaties l
        ON l.id = lp.locatie_id
     WHERE $whereSql
     ORDER BY lp.id DESC
     LIMIT :limit
     OFFSET :offset"
);

foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}

$stmt->bindValue(
    ':limit',
    $perPage,
    PDO::PARAM_INT
);

$stmt->bindValue(
    ':offset',
    $offset,
    PDO::PARAM_INT
);

$stmt->execute();
$rows = $stmt->fetchAll();

$locations = $pdo
    ->query(
        'SELECT id, naam
         FROM locaties
         WHERE actief = 1
         ORDER BY naam'
    )
    ->fetchAll();

include __DIR__ . '/header.php';
?>

<div class="page-head">

    <div>
        <h1>Leerpartijen</h1>

        <p>
            Zoek, bekijk, wijzig en beheer leerpartijen.
        </p>
    </div>

    <a
        class="btn btn-primary"
        href="partij_toevoegen.php"
    >
        ＋ Nieuwe leerpartij
    </a>

</div>

<section class="card">

<form
    class="filters"
    method="get"
>

    <input
        name="zoek"
        value="<?= e($search) ?>"
        placeholder="Zoek op label, herkomst of locatie..."
    >

    <select name="status">

        <option value="">
            Alle statussen
        </option>

        <?php foreach (
            [
                'Op voorraad',
                'Gereserveerd',
                'Verwerkt'
            ] as $option
        ): ?>

            <option
                value="<?= e($option) ?>"
                <?= $status === $option
                    ? 'selected'
                    : '' ?>
            >
                <?= e($option) ?>
            </option>

        <?php endforeach; ?>

    </select>

    <select name="locatie_id">

        <option value="0">
            Alle locaties
        </option>

        <?php foreach ($locations as $location): ?>

            <option
                value="<?= $location['id'] ?>"
                <?= $locationId ===
                    (int) $location['id']
                    ? 'selected'
                    : '' ?>
            >
                <?= e($location['naam']) ?>
            </option>

        <?php endforeach; ?>

    </select>

    <button
        class="btn btn-primary"
        type="submit"
    >
        Zoeken
    </button>

    <a
        class="btn btn-secondary"
        href="leerpartijen.php"
    >
        Reset
    </a>

</form>

<div class="table-wrap">

<table>

<thead>
    <tr>
        <th>Label</th>
        <th>Herkomst</th>
        <th>Locatie</th>
        <th>Gewicht</th>
        <th>Status</th>
        <th>Datum</th>
        <th>Acties</th>
    </tr>
</thead>

<tbody>

<?php if (!$rows): ?>

    <tr>
        <td
            colspan="7"
            class="empty"
        >
            Geen leerpartijen gevonden.
        </td>
    </tr>

<?php endif; ?>

<?php foreach ($rows as $row): ?>

    <tr>

        <td>
            <a
                class="table-link"
                href="partij_bekijken.php?id=<?= $row['id'] ?>"
            >
                <strong>
                    <?= e($row['label']) ?>
                </strong>
            </a>
        </td>

        <td>
            <?= e($row['herkomst']) ?>
        </td>

        <td>
            <?= e($row['locatie']) ?>
        </td>

        <td>
            <?= number_format(
                (float) $row['gewicht_kg'],
                2,
                ',',
                '.'
            ) ?> kg
        </td>

        <td>
            <span
                class="status <?= status_class(
                    $row['status']
                ) ?>"
            >
                <?= e($row['status']) ?>
            </span>
        </td>

        <td>
            <?= e(
                date(
                    'd-m-Y',
                    strtotime(
                        $row['datum_toegevoegd']
                    )
                )
            ) ?>
        </td>

        <td>
            <div class="actions">

                <a
                    class="icon-btn"
                    title="Bekijken"
                    href="partij_bekijken.php?id=<?= $row['id'] ?>"
                >
                    ◉
                </a>

                <a
                    class="icon-btn"
                    title="Bewerken"
                    href="partij_bewerken.php?id=<?= $row['id'] ?>"
                >
                    ✎
                </a>

                <?php if (is_admin()): ?>

                    <form
                        method="post"
                        action="partij_verwijderen.php"
                        class="inline-form"
                        data-confirm="Weet je zeker dat je deze leerpartij wilt verwijderen?"
                    >

                        <?= csrf_field() ?>

                        <input
                            type="hidden"
                            name="id"
                            value="<?= $row['id'] ?>"
                        >

                        <button
                            class="icon-btn danger"
                            title="Verwijderen"
                            type="submit"
                        >
                            🗑
                        </button>

                    </form>

                <?php endif; ?>

            </div>
        </td>

    </tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

<div class="pagination">

    <span>
        <?= $total ?> resultaten
    </span>

    <div>

        <?php for (
            $p = 1;
            $p <= $totalPages;
            $p++
        ): ?>

            <a
                class="<?= $p === $page
                    ? 'current'
                    : '' ?>"
                href="?<?= http_build_query(
                    array_merge(
                        $_GET,
                        ['pagina' => $p]
                    )
                ) ?>"
            >
                <?= $p ?>
            </a>

        <?php endfor; ?>

    </div>

</div>

</section>

<?php include __DIR__ . '/footer.php'; ?>
