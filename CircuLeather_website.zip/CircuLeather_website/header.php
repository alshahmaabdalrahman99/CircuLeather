<?php

declare(strict_types=1);

require_login();

$pageTitle = $pageTitle ?? APP_NAME;
$currentPage = basename($_SERVER['PHP_SELF']);
$success = flash('success');
$error = flash('error');
?>
<!doctype html>
<html lang="nl">
<head>
    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>
        <?= e($pageTitle) ?> |
        <?= e(APP_NAME) ?>
    </title>

    <link
        rel="stylesheet"
        href="style.css"
    >
</head>
<body>

<div class="app-shell">

    <aside class="sidebar">

        <a
            class="brand"
            href="index.php"
        >
            <span class="brand-mark">◒</span>

            <span>
                <strong>CircuLeather</strong>
                <small>Leerbeheer</small>
            </span>
        </a>

        <nav class="nav">

            <a
                class="<?= $currentPage === 'index.php'
                    ? 'active'
                    : '' ?>"
                href="index.php"
            >
                <span>⌂</span>
                Dashboard
            </a>

            <a
                class="<?= in_array(
                    $currentPage,
                    [
                        'leerpartijen.php',
                        'partij_toevoegen.php',
                        'partij_bekijken.php',
                        'partij_bewerken.php'
                    ],
                    true
                ) ? 'active' : '' ?>"
                href="leerpartijen.php"
            >
                <span>▣</span>
                Leerpartijen
            </a>

            <a
                class="<?= $currentPage ===
                    'partij_toevoegen.php'
                    ? 'active'
                    : '' ?>"
                href="partij_toevoegen.php"
            >
                <span>＋</span>
                Nieuwe partij
            </a>

            <a
                class="<?= in_array(
                    $currentPage,
                    [
                        'locaties.php',
                        'locatie_toevoegen.php',
                        'locatie_bewerken.php'
                    ],
                    true
                ) ? 'active' : '' ?>"
                href="locaties.php"
            >
                <span>⌖</span>
                Locaties
            </a>

            <a
                href="export.php"
            >
                <span>⇩</span>
                Export CSV
            </a>

            <?php if (is_admin()): ?>

                <a
                    class="<?= in_array(
                        $currentPage,
                        [
                            'gebruikers.php',
                            'gebruiker_toevoegen.php',
                            'gebruiker_bewerken.php'
                        ],
                        true
                    ) ? 'active' : '' ?>"
                    href="gebruikers.php"
                >
                    <span>♙</span>
                    Gebruikers
                </a>

            <?php endif; ?>

        </nav>

        <div class="sidebar-bottom">

            <div class="side-user">

                <div class="avatar">
                    <?= e(
                        strtoupper(
                            substr(
                                current_user()['naam'] ??
                                'G',
                                0,
                                1
                            )
                        )
                    ) ?>
                </div>

                <div>
                    <strong>
                        <?= e(
                            current_user()['naam'] ??
                            'Gebruiker'
                        ) ?>
                    </strong>

                    <small>
                        <?= e(
                            current_user()['rol'] ??
                            'user'
                        ) ?>
                    </small>
                </div>

            </div>

            <a
                class="logout-link"
                href="logout.php"
            >
                ↪ Uitloggen
            </a>

        </div>

    </aside>

    <main class="main">

        <header class="topbar">
            <div class="topbar-title">
                CircuLeather beheersysteem
            </div>

            <div class="user-menu">
                👤
                <?= e(
                    current_user()['naam'] ??
                    'Gebruiker'
                ) ?>
            </div>
        </header>

        <div class="content">

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <?= e($success) ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-error">
                    <?= e($error) ?>
                </div>
            <?php endif; ?>
