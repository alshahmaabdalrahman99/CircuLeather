<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

require_admin();

$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare(
    'SELECT *
     FROM locaties
     WHERE id = :id'
);

$stmt->execute([
    ':id' => $id
]);

$location = $stmt->fetch();

if (!$location) {
    http_response_code(404);
    exit('Locatie niet gevonden.');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $naam = trim(
        $_POST['naam'] ?? ''
    );

    $omschrijving = trim(
        $_POST['omschrijving'] ?? ''
    );

    if ($naam === '') {
        $errors[] = 'Naam is verplicht.';
    }

    if (!$errors) {
        try {
            $update = $pdo->prepare(
                'UPDATE locaties
                 SET
                    naam = :naam,
                    omschrijving = :omschrijving
                 WHERE id = :id'
            );

            $update->execute([
                ':naam' => $naam,
                ':omschrijving' =>
                    $omschrijving ?: null,
                ':id' => $id
            ]);

            flash(
                'success',
                'Locatie is aangepast.'
            );

            redirect('locaties.php');
        } catch (PDOException $e) {
            $errors[] =
                'Deze locatienaam bestaat al.';
        }
    }

    $location['naam'] = $naam;
    $location['omschrijving'] = $omschrijving;
}

$pageTitle = 'Locatie aanpassen';

include __DIR__ . '/header.php';
?>

<div class="page-head">

    <div>
        <a
            class="back-link"
            href="locaties.php"
        >
            ← Terug naar locaties
        </a>

        <h1>Locatie aanpassen</h1>

        <p>
            <?= e($location['naam']) ?>
        </p>
    </div>

</div>

<?php if ($errors): ?>

<div class="alert alert-error">
    <?php foreach ($errors as $error): ?>
        <div><?= e($error) ?></div>
    <?php endforeach; ?>
</div>

<?php endif; ?>

<section class="card form-card">

<form method="post">

    <?= csrf_field() ?>

    <div class="form-grid">

        <div class="form-group full">
            <label for="naam">
                Naam <span>*</span>
            </label>

            <input
                id="naam"
                name="naam"
                value="<?= e($location['naam']) ?>"
                required
            >
        </div>

        <div class="form-group full">
            <label for="omschrijving">
                Omschrijving
            </label>

            <textarea
                id="omschrijving"
                name="omschrijving"
                rows="4"
            ><?= e(
                $location['omschrijving']
            ) ?></textarea>
        </div>

    </div>

    <div class="form-actions">
        <a
            class="btn btn-secondary"
            href="locaties.php"
        >
            Annuleren
        </a>

        <button
            class="btn btn-primary"
            type="submit"
        >
            Wijzigingen opslaan
        </button>
    </div>

</form>

</section>

<?php include __DIR__ . '/footer.php'; ?>
