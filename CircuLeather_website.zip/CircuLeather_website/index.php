<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

$pageTitle = 'Dashboard';

/* Totale voorraad met status Op voorraad. */
$stmt = $pdo->query(
    "SELECT
        COALESCE(SUM(gewicht_kg), 0) AS totaal
     FROM leerpartijen
     WHERE status = 'Op voorraad'"
);

$totalStock = (float) $stmt->fetch()['totaal'];

/* Totaal aantal leerpartijen. */
$stmt = $pdo->query(
    'SELECT COUNT(*) AS totaal
     FROM leerpartijen'
);

$totalParties = (int) $stmt->fetch()['totaal'];

/* Totaal aantal actieve locaties. */
$stmt = $pdo->query(
    'SELECT COUNT(*) AS totaal
     FROM locaties
     WHERE actief = 1'
);

$totalLocations = (int) $stmt->fetch()['totaal'];

/* Aantal verschillende herkomsten. */
$stmt = $pdo->query(
    'SELECT COUNT(DISTINCT herkomst) AS totaal
     FROM leerpartijen'
);

$totalOrigins = (int) $stmt->fetch()['totaal'];

/* Laatste zes leerpartijen. */
$stmt = $pdo->query(
    "SELECT
        lp.id,
        lp.label,
        lp.herkomst,
        lp.gewicht_kg,
        lp.datum_toegevoegd,
        lp.status,
        l.naam AS locatie
     FROM leerpartijen lp
     JOIN locaties l
        ON l.id = lp.locatie_id
     ORDER BY lp.id DESC
     LIMIT 6"
);

$recentParties = $stmt->fetchAll();

/* Voorraad per actieve locatie. */
$stmt = $pdo->query(
    "SELECT
        l.naam,
        COALESCE(
            SUM(
                CASE
                    WHEN lp.status = 'Op voorraad'
                    THEN lp.gewicht_kg
                    ELSE 0
                END
            ),
            0
        ) AS voorraad
     FROM locaties l
     LEFT JOIN leerpartijen lp
        ON lp.locatie_id = l.id
     WHERE l.actief = 1
     GROUP BY l.id, l.naam
     ORDER BY voorraad DESC"
);

$locationStock = $stmt->fetchAll();

$maxLocation = 1;

foreach ($locationStock as $row) {
    $maxLocation = max(
        $maxLocation,
        (float) $row['voorraad']
    );
}

include __DIR__ . '/header.php';
?>

<div class="page-head">

    <div>
        <h1>Dashboard</h1>

        <p>
            Overzicht van voorraad, locaties en leerpartijen.
        </p>
    </div>

    <a
        class="btn btn-primary"
        href="partij_toevoegen.php"
    >
        ＋ Nieuwe leerpartij
    </a>

</div>

<div class="stats-grid">

    <div class="stat-card">
        <span class="stat-icon">▣</span>

        <strong>
            <?= number_format(
                $totalStock,
                2,
                ',',
                '.'
            ) ?> kg
        </strong>

        <small>Totale voorraad</small>
    </div>

    <div class="stat-card">
        <span class="stat-icon">◫</span>

        <strong>
            <?= $totalParties ?>
        </strong>

        <small>Leerpartijen</small>
    </div>

    <div class="stat-card">
        <span class="stat-icon">⌖</span>

        <strong>
            <?= $totalLocations ?>
        </strong>

        <small>Actieve locaties</small>
    </div>

    <div class="stat-card">
        <span class="stat-icon">◆</span>

        <strong>
            <?= $totalOrigins ?>
        </strong>

        <small>Unieke herkomsten</small>
    </div>

</div>

<div class="dashboard-grid">

    <section class="card">

        <div class="card-head">
            <h2>Voorraad per locatie</h2>

            <a href="locaties.php">
                Beheer locaties →
            </a>
        </div>

        <?php foreach ($locationStock as $row): ?>

            <?php
            $width =
                ((float) $row['voorraad'] /
                $maxLocation) * 100;
            ?>

            <div class="location-row">

                <span>
                    <?= e($row['naam']) ?>
                </span>

                <div class="bar">
                    <i
                        style="width: <?= $width ?>%"
                    ></i>
                </div>

                <strong>
                    <?= number_format(
                        (float) $row['voorraad'],
                        0,
                        ',',
                        '.'
                    ) ?> kg
                </strong>

            </div>

        <?php endforeach; ?>

    </section>

    <section class="card">

        <div class="card-head">
            <h2>Recente leerpartijen</h2>

            <a href="leerpartijen.php">
                Bekijk alle →
            </a>
        </div>

        <div class="table-wrap">

            <table>

                <thead>
                    <tr>
                        <th>Label</th>
                        <th>Herkomst</th>
                        <th>Locatie</th>
                        <th>Gewicht</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>

                <?php foreach ($recentParties as $row): ?>

                    <tr>

                        <td>
                            <a
                                class="table-link"
                                href="partij_bekijken.php?id=<?= $row['id'] ?>"
                            >
                                <strong>
                                    <?= e($row['label']) ?>
                                </strong>
                            </a>
                        </td>

                        <td>
                            <?= e($row['herkomst']) ?>
                        </td>

                        <td>
                            <?= e($row['locatie']) ?>
                        </td>

                        <td>
                            <?= number_format(
                                (float) $row['gewicht_kg'],
                                2,
                                ',',
                                '.'
                            ) ?> kg
                        </td>

                        <td>
                            <span
                                class="status <?= status_class(
                                    $row['status']
                                ) ?>"
                            >
                                <?= e($row['status']) ?>
                            </span>
                        </td>

                    </tr>

                <?php endforeach; ?>

                </tbody>

            </table>

        </div>

    </section>

</div>

<?php include __DIR__ . '/footer.php'; ?>
