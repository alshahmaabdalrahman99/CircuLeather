<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

if (is_logged_in()) {
    redirect('index.php');
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $email = trim(
        $_POST['email'] ?? ''
    );

    $password = $_POST['password'] ?? '';

    if (login_user($email, $password)) {
        redirect('index.php');
    }

    $error =
        'E-mailadres of wachtwoord is onjuist.';
}
?>
<!doctype html>
<html lang="nl">
<head>
    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>Inloggen | CircuLeather</title>

    <link
        rel="stylesheet"
        href="style.css"
    >
</head>
<body class="login-page">

<div class="login-card">

    <div class="login-logo">
        <span>◒</span>

        <div>
            <strong>CircuLeather</strong>
            <small>Leerbeheer</small>
        </div>
    </div>

    <h1>Inloggen</h1>

    <p class="login-subtitle">
        Log in om leerpartijen te beheren.
    </p>

    <?php if ($error): ?>
        <div class="alert alert-error">
            <?= e($error) ?>
        </div>
    <?php endif; ?>

    <form
        method="post"
        class="login-form"
    >

        <?= csrf_field() ?>

        <label for="email">
            E-mailadres
        </label>

        <input
            id="email"
            name="email"
            type="email"
            autocomplete="username"
            required
        >

        <label for="password">
            Wachtwoord
        </label>

        <input
            id="password"
            name="password"
            type="password"
            autocomplete="current-password"
            required
        >

        <button
            class="btn btn-primary btn-wide"
            type="submit"
        >
            Inloggen
        </button>

    </form>

    <div class="demo-login">
        <strong>Demo-account</strong>

        <span>
            admin@circuleather.nl
        </span>

        <span>
            Wachtwoord: Admin123!
        </span>
    </div>

</div>

</body>
</html>
