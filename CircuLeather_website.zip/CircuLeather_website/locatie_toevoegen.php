<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

require_admin();

$pageTitle = 'Nieuwe locatie';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $naam = trim(
        $_POST['naam'] ?? ''
    );

    $omschrijving = trim(
        $_POST['omschrijving'] ?? ''
    );

    if ($naam === '') {
        $errors[] = 'Naam is verplicht.';
    }

    if (!$errors) {
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO locaties (
                    naam,
                    omschrijving,
                    actief
                ) VALUES (
                    :naam,
                    :omschrijving,
                    1
                )'
            );

            $stmt->execute([
                ':naam' => $naam,
                ':omschrijving' =>
                    $omschrijving ?: null
            ]);

            flash(
                'success',
                'Locatie is toegevoegd.'
            );

            redirect('locaties.php');
        } catch (PDOException $e) {
            $errors[] =
                'Deze locatienaam bestaat al.';
        }
    }
}

include __DIR__ . '/header.php';
?>

<div class="page-head">
    <div>
        <a
            class="back-link"
            href="locaties.php"
        >
            ← Terug naar locaties
        </a>

        <h1>Nieuwe locatie</h1>

        <p>
            Maak een nieuwe opslaglocatie aan.
        </p>
    </div>
</div>

<?php if ($errors): ?>

<div class="alert alert-error">
    <?php foreach ($errors as $error): ?>
        <div><?= e($error) ?></div>
    <?php endforeach; ?>
</div>

<?php endif; ?>

<section class="card form-card">

<form method="post">

    <?= csrf_field() ?>

    <div class="form-grid">

        <div class="form-group full">
            <label for="naam">
                Naam <span>*</span>
            </label>

            <input
                id="naam"
                name="naam"
                value="<?= e(
                    $_POST['naam'] ?? ''
                ) ?>"
                required
            >
        </div>

        <div class="form-group full">
            <label for="omschrijving">
                Omschrijving
            </label>

            <textarea
                id="omschrijving"
                name="omschrijving"
                rows="4"
            ><?= e(
                $_POST['omschrijving'] ?? ''
            ) ?></textarea>
        </div>

    </div>

    <div class="form-actions">
        <a
            class="btn btn-secondary"
            href="locaties.php"
        >
            Annuleren
        </a>

        <button
            class="btn btn-primary"
            type="submit"
        >
            Locatie opslaan
        </button>
    </div>

</form>

</section>

<?php include __DIR__ . '/footer.php'; ?>
