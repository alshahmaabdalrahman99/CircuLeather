<?php

declare(strict_types=1);

/*
 * Basisinstellingen van de applicatie.

 */
const DB_HOST = 'localhost';
const DB_NAME = 'circuleather';
const DB_USER = 'root';
const DB_PASS = '';

const APP_NAME = 'CircuLeather';
const MAX_UPLOAD_MB = 5;

const UPLOAD_DIR = __DIR__ . DIRECTORY_SEPARATOR . 'uploads';
const UPLOAD_URL = 'uploads';

ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Lax');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST .
        ';dbname=' . DB_NAME .
        ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);

    exit(
        'Databaseverbinding mislukt. ' .
        'Controleer config.php en of MySQL draait.'
    );
}

if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0775, true);
}
