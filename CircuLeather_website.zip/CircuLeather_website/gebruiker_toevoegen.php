<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

require_admin();

$pageTitle = 'Nieuwe gebruiker';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $naam = trim($_POST['naam'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['wachtwoord'] ?? '';
    $rol = $_POST['rol'] ?? 'user';

    if ($naam === '') {
        $errors[] = 'Naam is verplicht.';
    }

    if (!filter_var(
        $email,
        FILTER_VALIDATE_EMAIL
    )) {
        $errors[] =
            'Vul een geldig e-mailadres in.';
    }

    if (strlen($password) < 8) {
        $errors[] =
            'Wachtwoord moet minimaal 8 tekens bevatten.';
    }

    if (!in_array(
        $rol,
        ['admin', 'user'],
        true
    )) {
        $errors[] = 'Ongeldige rol.';
    }

    if (!$errors) {
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO gebruikers (
                    naam,
                    email,
                    wachtwoord_hash,
                    rol,
                    actief
                ) VALUES (
                    :naam,
                    :email,
                    :hash,
                    :rol,
                    1
                )'
            );

            $stmt->execute([
                ':naam' => $naam,
                ':email' => $email,
                ':hash' => password_hash(
                    $password,
                    PASSWORD_DEFAULT
                ),
                ':rol' => $rol
            ]);

            flash(
                'success',
                'Gebruiker is toegevoegd.'
            );

            redirect('gebruikers.php');
        } catch (PDOException $e) {
            $errors[] =
                'Dit e-mailadres is al in gebruik.';
        }
    }
}

include __DIR__ . '/header.php';
?>

<div class="page-head">

    <div>
        <a
            class="back-link"
            href="gebruikers.php"
        >
            ← Terug naar gebruikers
        </a>

        <h1>Nieuwe gebruiker</h1>

        <p>
            Maak een nieuw account aan.
        </p>
    </div>

</div>

<?php if ($errors): ?>

<div class="alert alert-error">
    <?php foreach ($errors as $error): ?>
        <div><?= e($error) ?></div>
    <?php endforeach; ?>
</div>

<?php endif; ?>

<section class="card form-card">

<form method="post">

    <?= csrf_field() ?>

    <div class="form-grid">

        <div class="form-group full">
            <label for="naam">
                Naam <span>*</span>
            </label>

            <input
                id="naam"
                name="naam"
                value="<?= e(
                    $_POST['naam'] ?? ''
                ) ?>"
                required
            >
        </div>

        <div class="form-group">
            <label for="email">
                E-mailadres <span>*</span>
            </label>

            <input
                id="email"
                name="email"
                type="email"
                value="<?= e(
                    $_POST['email'] ?? ''
                ) ?>"
                required
            >
        </div>

        <div class="form-group">
            <label for="rol">Rol</label>

            <select
                id="rol"
                name="rol"
            >
                <option value="user">
                    Gebruiker
                </option>

                <option value="admin">
                    Beheerder
                </option>
            </select>
        </div>

        <div class="form-group full">
            <label for="wachtwoord">
                Wachtwoord <span>*</span>
            </label>

            <input
                id="wachtwoord"
                name="wachtwoord"
                type="password"
                minlength="8"
                required
            >
        </div>

    </div>

    <div class="form-actions">

        <a
            class="btn btn-secondary"
            href="gebruikers.php"
        >
            Annuleren
        </a>

        <button
            class="btn btn-primary"
            type="submit"
        >
            Gebruiker opslaan
        </button>

    </div>

</form>

</section>

<?php include __DIR__ . '/footer.php'; ?>
