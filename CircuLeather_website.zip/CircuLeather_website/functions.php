<?php

declare(strict_types=1);

/* HTML-uitvoer veilig maken. */
function e(mixed $value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/* Doorsturen naar een andere pagina. */
function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

/* Eenmalige melding bewaren. */
function flash(
    string $key,
    ?string $message = null
): ?string {
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return null;
    }

    $value = $_SESSION['flash'][$key] ?? null;
    unset($_SESSION['flash'][$key]);

    return $value;
}

/* CSRF-token voor formulieren. */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] =
            bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return
        '<input type="hidden" ' .
        'name="csrf_token" value="' .
        e(csrf_token()) .
        '">';
}

function verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';

    if (!hash_equals(
        $_SESSION['csrf_token'] ?? '',
        $token
    )) {
        http_response_code(419);
        exit('Ongeldige formulierbeveiliging.');
    }
}

/* Controleren of iemand is ingelogd. */
function is_logged_in(): bool
{
    return !empty($_SESSION['user']);
}

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}
#Controleert of de gebruiker is ingelogd
function require_login(): void
{
    if (!is_logged_in()) {
        redirect('login.php');
    }
}

/* Alleen beheerders krijgen toegang. */
function is_admin(): bool
{
    return (current_user()['rol'] ?? '') === 'admin';
}

function require_admin(): void
{
    require_login();

    if (!is_admin()) {
        http_response_code(403);
        exit('Geen toegang. Alleen beheerders mogen dit openen.');
    }
}
#Koppelt een status aan een CSS-klasse
function status_class(string $status): string
{
    return match ($status) {
        'Op voorraad' => 'status-green',
        'Gereserveerd' => 'status-yellow',
        'Verwerkt' => 'status-gray',
        default => 'status-gray'
    };
}

/* Volgend label voor een nieuwe partij. */
function get_next_label(PDO $pdo): string
{
    $stmt = $pdo->query(
        'SELECT COALESCE(MAX(id), 0) + 1 AS next_id
         FROM leerpartijen'
    );

    $nextId = (int) $stmt->fetch()['next_id'];

    return 'CL-' .
        str_pad(
            (string) $nextId,
            5,
            '0',
            STR_PAD_LEFT
        );
}

/* Foto uploaden en veilig opslaan. */
function save_uploaded_image(array $file): ?string
{
    if (
        ($file['error'] ?? UPLOAD_ERR_NO_FILE) ===
        UPLOAD_ERR_NO_FILE
    ) {
        return null;
    }

    if (($file['error'] ?? 0) !== UPLOAD_ERR_OK) {
        throw new RuntimeException(
            'De foto kon niet worden geüpload.'
        );
    }

    $maxBytes =
        MAX_UPLOAD_MB * 1024 * 1024;

    if (($file['size'] ?? 0) > $maxBytes) {
        throw new RuntimeException(
            'De foto mag maximaal ' .
            MAX_UPLOAD_MB .
            ' MB zijn.'
        );
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);

    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp'
    ];

    if (!isset($allowed[$mime])) {
        throw new RuntimeException(
            'Gebruik een JPG-, PNG- of WEBP-bestand.'
        );
    }

    $filename =
        bin2hex(random_bytes(12)) .
        '.' .
        $allowed[$mime];

    $target =
        UPLOAD_DIR .
        DIRECTORY_SEPARATOR .
        $filename;

    if (!move_uploaded_file(
        $file['tmp_name'],
        $target
    )) {
        throw new RuntimeException(
            'De foto kon niet worden opgeslagen.'
        );
    }

    return $filename;
}

function delete_uploaded_image(
    ?string $filename
): void {
    if (!$filename) {
        return;
    }

    $safeName = basename($filename);

    $path =
        UPLOAD_DIR .
        DIRECTORY_SEPARATOR .
        $safeName;

    if (is_file($path)) {
        unlink($path);
    }
}
