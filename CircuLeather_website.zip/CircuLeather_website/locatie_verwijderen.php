<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('locaties.php');
}

verify_csrf();

$id = (int) ($_POST['id'] ?? 0);

/* Een locatie mag niet weg als er partijen aan gekoppeld zijn. */
$stmt = $pdo->prepare(
    'SELECT COUNT(*) AS totaal
     FROM leerpartijen
     WHERE locatie_id = :id'
);

$stmt->execute([
    ':id' => $id
]);

$count = (int) $stmt->fetch()['totaal'];

if ($count > 0) {
    flash(
        'error',
        'Deze locatie bevat nog leerpartijen.'
    );

    redirect('locaties.php');
}

$update = $pdo->prepare(
    'UPDATE locaties
     SET actief = 0
     WHERE id = :id'
);

$update->execute([
    ':id' => $id
]);

flash(
    'success',
    'Locatie is gedeactiveerd.'
);

redirect('locaties.php');
