<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

require_admin();

$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare(
    'SELECT *
     FROM gebruikers
     WHERE id = :id'
);

$stmt->execute([
    ':id' => $id
]);

$user = $stmt->fetch();

if (!$user) {
    http_response_code(404);
    exit('Gebruiker niet gevonden.');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $naam = trim($_POST['naam'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $rol = $_POST['rol'] ?? 'user';
    $actief = (int) ($_POST['actief'] ?? 1);
    $newPassword = $_POST['wachtwoord'] ?? '';

    if ($naam === '') {
        $errors[] = 'Naam is verplicht.';
    }

    if (!filter_var(
        $email,
        FILTER_VALIDATE_EMAIL
    )) {
        $errors[] =
            'Vul een geldig e-mailadres in.';
    }

    if (!in_array(
        $rol,
        ['admin', 'user'],
        true
    )) {
        $errors[] = 'Ongeldige rol.';
    }

    if (
        $newPassword !== '' &&
        strlen($newPassword) < 8
    ) {
        $errors[] =
            'Wachtwoord moet minimaal 8 tekens bevatten.';
    }

    /* Een gebruiker mag zijn eigen account niet uitschakelen. */
    if (
        $id === (int) current_user()['id'] &&
        $actief === 0
    ) {
        $errors[] =
            'Je eigen account mag je niet uitschakelen.';
    }

    if (!$errors) {
        try {
            if ($newPassword !== '') {
                $sql =
                    'UPDATE gebruikers
                     SET
                        naam = :naam,
                        email = :email,
                        rol = :rol,
                        actief = :actief,
                        wachtwoord_hash = :hash
                     WHERE id = :id';

                $params = [
                    ':naam' => $naam,
                    ':email' => $email,
                    ':rol' => $rol,
                    ':actief' => $actief,
                    ':hash' => password_hash(
                        $newPassword,
                        PASSWORD_DEFAULT
                    ),
                    ':id' => $id
                ];
            } else {
                $sql =
                    'UPDATE gebruikers
                     SET
                        naam = :naam,
                        email = :email,
                        rol = :rol,
                        actief = :actief
                     WHERE id = :id';

                $params = [
                    ':naam' => $naam,
                    ':email' => $email,
                    ':rol' => $rol,
                    ':actief' => $actief,
                    ':id' => $id
                ];
            }

            $update = $pdo->prepare($sql);
            $update->execute($params);

            /* De sessie bijwerken als je eigen account is gewijzigd. */
            if ($id === (int) current_user()['id']) {
                $_SESSION['user']['naam'] = $naam;
                $_SESSION['user']['email'] = $email;
                $_SESSION['user']['rol'] = $rol;
            }

            flash(
                'success',
                'Gebruiker is aangepast.'
            );

            redirect('gebruikers.php');
        } catch (PDOException $e) {
            $errors[] =
                'Dit e-mailadres is al in gebruik.';
        }
    }

    $user['naam'] = $naam;
    $user['email'] = $email;
    $user['rol'] = $rol;
    $user['actief'] = $actief;
}

$pageTitle = 'Gebruiker aanpassen';

include __DIR__ . '/header.php';
?>

<div class="page-head">

    <div>
        <a
            class="back-link"
            href="gebruikers.php"
        >
            ← Terug naar gebruikers
        </a>

        <h1>Gebruiker aanpassen</h1>

        <p>
            <?= e($user['naam']) ?>
        </p>
    </div>

</div>

<?php if ($errors): ?>

<div class="alert alert-error">
    <?php foreach ($errors as $error): ?>
        <div><?= e($error) ?></div>
    <?php endforeach; ?>
</div>

<?php endif; ?>

<section class="card form-card">

<form method="post">

    <?= csrf_field() ?>

    <div class="form-grid">

        <div class="form-group full">
            <label for="naam">
                Naam <span>*</span>
            </label>

            <input
                id="naam"
                name="naam"
                value="<?= e($user['naam']) ?>"
                required
            >
        </div>

        <div class="form-group">
            <label for="email">
                E-mailadres <span>*</span>
            </label>

            <input
                id="email"
                name="email"
                type="email"
                value="<?= e($user['email']) ?>"
                required
            >
        </div>

        <div class="form-group">
            <label for="rol">Rol</label>

            <select
                id="rol"
                name="rol"
            >

                <option
                    value="user"
                    <?= $user['rol'] === 'user'
                        ? 'selected'
                        : '' ?>
                >
                    Gebruiker
                </option>

                <option
                    value="admin"
                    <?= $user['rol'] === 'admin'
                        ? 'selected'
                        : '' ?>
                >
                    Beheerder
                </option>

            </select>
        </div>

        <div class="form-group">
            <label for="actief">Status</label>

            <select
                id="actief"
                name="actief"
            >

                <option
                    value="1"
                    <?= (int) $user['actief'] === 1
                        ? 'selected'
                        : '' ?>
                >
                    Actief
                </option>

                <option
                    value="0"
                    <?= (int) $user['actief'] === 0
                        ? 'selected'
                        : '' ?>
                >
                    Inactief
                </option>

            </select>
        </div>

        <div class="form-group full">
            <label for="wachtwoord">
                Nieuw wachtwoord
            </label>

            <input
                id="wachtwoord"
                name="wachtwoord"
                type="password"
                minlength="8"
            >

            <small>
                Leeg laten om het huidige wachtwoord te behouden.
            </small>
        </div>

    </div>

    <div class="form-actions">

        <a
            class="btn btn-secondary"
            href="gebruikers.php"
        >
            Annuleren
        </a>

        <button
            class="btn btn-primary"
            type="submit"
        >
            Wijzigingen opslaan
        </button>

    </div>

</form>

</section>

<?php include __DIR__ . '/footer.php'; ?>
